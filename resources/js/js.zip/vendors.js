//@prepros-append ../../node_modules/jquery/dist/jquery.min.js
//@prepros-append ../../node_modules/bootstrap/dist/js/bootstrap.min.js
//@prepros-append ../../node_modules/bootstrap/js/dist/popover.js
//@prepros-append main.js